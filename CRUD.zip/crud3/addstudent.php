<?php 
include_once('./header.php');
if (!isset($_SESSION['uname'])) {
    header("location: login.php");
}

$cities = ['Badarganj','Bajitpur','Bandarban','Baniachang','Barisal','Bera','Bhairab Bazar','Bhandaria', 'Abhaynagar','Bheramara','Bhola','Bogra','Burhanuddin','Char Bhadrasan','Chhagalnaiya','Chhatak','Chilmari','Chittagong','Comilla','Cox\'s Bazar','Dhaka','Dinajpur','Dohar','Faridpur','Fatikchari','Feni','Gafargaon','Gaurnadi','Habiganj','Hajiganj','Ishurdi','Jamalpur','Jessore','Jhingergacha','Joypur Hat','Kalia','Kaliganj','Kesabpur','Khagrachhari','Khulna','Kishorganj','Kushtia','Laksham','Lakshmipur','Lalmanirhat','Lalmohan','Madaripur','Manikchari','Mathba','Maulavi Bazar','Mehendiganj','Mirzapur','Morrelgonj','Muktagacha','Mymensingh','Nabinagar','Nagarpur','Nageswari','Nalchiti','Narail','Narayanganj','Narsingdi','Nawabganj','Netrakona','Pabna','Palang','Panchagarh','Par Naogaon','Parbatipur','Patiya','Phultala','Pirgaaj','Pirojpur','Raipur','Rajshahi','Ramganj','Rangpur','Raojan','Saidpur','Sakhipur','Sandwip','Sarankhola','Sarishabari','Satkania','Satkhira','Shahzadpur','Sherpur','Shibganj','Sirajganj','Sylhet','Tangail','Teknaf','Thakurgaon','Tungi','Tungipara','Uttar Char Fasson'];

if (isset($_POST['submit'])) {
    $sname = $_POST['sname'];
    $sphone = $_POST['sphone'];
    $gender = $_POST['gender'] ?? null;
    $scity = $_POST['scity'];

    if (empty($sname)) {
        $errsnamecls = "border-danger";
       $errsname = 'data-bs-toggle="tooltip" data-bs-placement="top" title="Please Write Student\'s Name"';
    }elseif(!preg_match('/^["A-Za-z. "]*$/' , $sname)){
        $errsnamecls = "border-danger";
       $errsname = 'data-bs-toggle="tooltip" data-bs-placement="top" title="Please Write a valid Student\'s Name"';
    }else{
        $crrsname = $sname;
    }
    if (empty($sphone)) {
        $errsphncls = "border-danger";
       $errsphone = 'data-bs-toggle="tooltip" data-bs-placement="top" title="Please Write Student\'s Phone Number"';
    }elseif(!preg_match('/^["0-9+ "]*$/' , $sphone)){
        $errsphncls = "border-danger";
       $errsphone = 'data-bs-toggle="tooltip" data-bs-placement="top" title="Please Write a valid Phone Number"';
    }elseif(strlen($sphone) < 9 || strlen($sphone)  > 11){
        $errsphncls = "border-danger";
       $errsphone = 'data-bs-toggle="tooltip" data-bs-placement="top" title="Please Write a valid Phone Number"';
    }else{
        $crrsphone = $sphone;
    }
    if (empty($gender)) {
       $errgender = "<span style='color:red;'>Please Select Your Gender</span>";
    }else{
        $crrgender = $gender;
    }
    if (empty($scity)) {
        $errscitycls = "border-danger";
       $errcity = "<span style='color:red;'>Please Select Your City</span>";

    }else{
        $crrcity = $scity;
    }

    if (isset($crrsname) && isset($crrsphone) && isset($crrgender) && isset($crrcity)) {
        $insert_query = "INSERT INTO `students` (`student_name`,`phone`,`gender`,`city`) VALUES ('$crrsname','$crrsphone','$crrgender','$crrcity')";
        $insert = $conn->query($insert_query);

        if (!$insert) {
            $err = "<script>alert('Something Went Wrong')</script>";
        }else{
            $success = "<script>alert('Student Added Successfully')</script>";
        }
    }    
}

?>

<div class="container">
<div class="row py-5 my-5">
    <div class="col-md-6 m-auto p-5 border shadow rounded">
        <h2 class="text-center">Add Student</h2>
        <?=  $err ?? $success ?? null ;?>
        <form action="" method="post">

        <input type="text" placeholder="Student's Name" class="form-control mt-4 <?= $errsnamecls ?? null;?>" name="sname" <?= $errsname ?? null;?>>

        <input type="text" placeholder="Student's Phone Number" class="form-control mt-4 <?= $errsphncls ?? null;?>" name="sphone" <?= $errsphone ?? null;?>>
        
        <label for="gender">Gender : </label>
        <input type="radio" name="gender" value="Male">Male
        <input type="radio" name="gender" value="Female" class="mt-4">Female
        <?= $errgender ?? null;?>
        <br>
        <select name="scity" id="" class="form-control mt-4 <?= $errscitycls ?? null;?>">
            <option value="">--select--</option>
            <?php 
            foreach ($cities as $city) {?>
            <option value="<?= $city?>"><?= $city?></option>
            <?php } ?>
        </select>
        <?= $errcity ?? null;?><br>
        <input type="submit" value="Add Student" class="btn btn-success btn-small mt-4" name="submit">
        </form>
    </div>
</div>
</div>
<?php 
include_once('./footer.php');
?>
    