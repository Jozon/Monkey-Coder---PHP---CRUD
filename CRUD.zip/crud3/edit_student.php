<?php 
include_once('./header.php');
if (!isset($_SESSION['uname'])) {
    header("location: login.php");
}


if (!isset($_GET['id'])) {
    header("location: stdinfo.php");
}else{
        $sid = $_GET['id'];
}

$select_query = "SELECT * FROM `students` WHERE `id` = $sid ";
$select = $conn->query($select_query);


if ($select->num_rows!=1) {
    header("location : stdinfo.php");
}
$data = $select->fetch_object();



$cities = ['Badarganj','Bajitpur','Bandarban','Baniachang','Barisal','Bera','Bhairab Bazar','Bhandaria', 'Abhaynagar','Bheramara','Bhola','Bogra','Burhanuddin','Char Bhadrasan','Chhagalnaiya','Chhatak','Chilmari','Chittagong','Comilla','Cox\'s Bazar','Dhaka','Dinajpur','Dohar','Faridpur','Fatikchari','Feni','Gafargaon','Gaurnadi','Habiganj','Hajiganj','Ishurdi','Jamalpur','Jessore','Jhingergacha','Joypur Hat','Kalia','Kaliganj','Kesabpur','Khagrachhari','Khulna','Kishorganj','Kushtia','Laksham','Lakshmipur','Lalmanirhat','Lalmohan','Madaripur','Manikchari','Mathba','Maulavi Bazar','Mehendiganj','Mirzapur','Morrelgonj','Muktagacha','Mymensingh','Nabinagar','Nagarpur','Nageswari','Nalchiti','Narail','Narayanganj','Narsingdi','Nawabganj','Netrakona','Pabna','Palang','Panchagarh','Par Naogaon','Parbatipur','Patiya','Phultala','Pirgaaj','Pirojpur','Raipur','Rajshahi','Ramganj','Rangpur','Raojan','Saidpur','Sakhipur','Sandwip','Sarankhola','Sarishabari','Satkania','Satkhira','Shahzadpur','Sherpur','Shibganj','Sirajganj','Sylhet','Tangail','Teknaf','Thakurgaon','Tungi','Tungipara','Uttar Char Fasson'];

if (isset($_POST['submit'])) {
    $sname = $_POST['sname'];
    $sphone = $_POST['sphone'];
    $gender = $_POST['gender'] ?? null;
    $scity = $_POST['scity'];

    if (empty($sname)) {
        $errsnamecls = "border-danger";
       $errsname = 'data-bs-toggle="tooltip" data-bs-placement="top" title="Please Write Student\'s Name"';
    }else{
        $crrsname = $sname;
    }
    if (empty($sphone)) {
        $errsphncls = "border-danger";
       $errsphone = 'data-bs-toggle="tooltip" data-bs-placement="top" title="Please Write Student\'s Phone Number"';
    }else{
        $crrphone = $sphone;
    }
    if (empty($gender)) {
       $errgender = "<span style='color:red;'>Please Select Your Gender</span>";
    }else{
        $crrgender = $gender;
    }
    if (empty($scity)) {
       $errcity = "<span style='color:red;'>Please Select Your City</span>";
    }else{
        $crrcity = $scity;
    }


    if (isset($crrsname) && isset($crrphone) && isset($crrgender) && isset($crrcity)) {
        $update_query = "UPDATE `students` SET `student_name`= '$crrsname',`phone`= '$crrphone',`gender`= '$crrgender',`city`='$crrcity' WHERE `id` = $sid";
        $update = $conn->query($update_query);

        if (!$update) {
            echo "<script>alert('Something Went Wrong')</script>";
        }else{
            echo "<script>alert('Student updated Successfully')</script>";
            echo "<meta http-equiv='refresh' content='0; url=stdinfo.php' />";
        }
    }
}

?>

<div class="container">
<div class="row py-5 my-5">
    <div class="col-md-6 m-auto p-5 border shadow rounded">
        <h2 class="text-center">Edit Student</h2>
        <form action="" method="post">

        <input type="text" value="<?= $data->student_name?>" class="form-control mt-4 <?= $errsnamecls ?? null;?>" name="sname" <?= $errsname ?? null;?>>

        <input type="text" value="<?= $data->phone?>" class="form-control mt-4 <?= $errsphncls ?? null;?>" name="sphone" <?= $errsphone ?? null;?>>
        
        <label for="gender">Gender : </label>
        <input type="radio" name="gender" value="Male" <?= ($data->gender == 'Male')? 'checked':null ;?>>Male
        <input type="radio" name="gender" value="Female" <?= ($data->gender == 'Female')? 'checked':null ;?> class="mt-4">Female
        <?= $errgender ?? null;?>
        <br>
        <select name="scity" id="" class="form-control mt-4">
            <option value="">--select--</option>
            <?php 
            foreach ($cities as $city) {?>
            <option value="<?= $city?>" <?= ($data->city == $city)? 'selected':null ;?>><?= $city?></option>
            <?php } ?>
        </select>
        <?= $errcity ?? null;?><br>
        <input type="submit" value="Update Student Information" class="btn btn-success btn-small mt-4" name="submit">
        </form>
    </div>
</div>
</div>
<?php 
include_once('./footer.php');
?>
    