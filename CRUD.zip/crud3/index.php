<?php 
include_once('./header.php');
if (isset($_POST['submit'])) {
    $search_student = $_POST['sname'];
    $Search_query = "SELECT * FROM `students` WHERE `student_name` LIKE '%$search_student%'";
    $Search = $conn->query($Search_query);
}


?>

<div class="container">
<div class="row py-5 my-5">
    <div class="col-md-10 m-auto p-5 border shadow rounded">
        <h2 class="text-center">Search Student</h2>
        <form action="" method="post">
        <input type="text" placeholder="Search Student By Name" class="form-control mt-4" name="sname">
        <input type="submit" value="Search Student" class="btn btn-success btn-small mt-4" name="submit">
        </form>
<?php if(isset($Search)){ ?>

    <h4 class="text-center border p-2 mt-4">Your Search Result For "<?= $search_student;?>"</h4>
        <table class= "table table-striped mt-3">
            <tr>
                <th>S. No</th>
                <th>Student's Name</th>
                <th>Phone Number</th>
                <th>Gender</th>
                <th>City</th>
                <th>Reg Time</th>
                <?php if(isset($_SESSION['uname'])) {?>
                <th>Actions</th>
                <?php } ?>
            </tr>
            <?php $x= 1; while ($data = $Search->fetch_object()) {    
            ?>
            <tr>
                <td><?= $x; ?></td>
                <td><?= $data->student_name?></td>
                <td><?= $data->phone?></td>
                <td><?= $data->gender?></td>
                <td><?= $data->city?></td>
                <td><?= date('d-M-Y' , strtotime($data->reg_time))?></td>
<?php if(isset($_SESSION['uname'])) {?>
                <td>
                <a href="./edit_student.php" class="btn btn-success btn-small mx-1 btn-hover" ><i class="fas fa-edit"></i></a>
                <a href="" class="btn btn-danger btn-small"><i class="fas fa-trash"></i>
            </a>
        </td>
<?php } ?>
            </tr>
            <?php $x++; } ?>
        </table>
<?php } ?>
    </div>
</div>
</div>
<?php 
include_once('./footer.php');
?>
    