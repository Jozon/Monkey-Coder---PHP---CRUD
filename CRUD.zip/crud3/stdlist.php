<?php 
include_once('./header.php');

    $select_query = "SELECT * FROM `students`";
    $select = $conn->query($select_query);

if (!isset($_GET['page'])) {
    header('location: stdlist.php?page=1');
}else{
    $pageNo = $_GET['page'];
}

$total_students = $select->num_rows;
$StudentPerPage = 2;
$totalpages = ceil($total_students/$StudentPerPage);
$start_point = ($pageNo-1)*$StudentPerPage;

$select_ayon_query = "SELECT * FROM `students` LIMIT $start_point,$StudentPerPage";
$select_ayon = $conn->query($select_ayon_query);

if ($pageNo > $totalpages) {
    header('location: stslist.php?page=1');
}
?>

<div class="container">
<div class="row py-5 my-5">
    <div class="col-md-10 m-auto p-5 border shadow rounded">
        <h2 class="text-center"> Student List</h2>
        <?php 
        

        if ($select->num_rows == 0) {
            echo "<div class='display-4'>No Student Record Found</div>";
        }else{
        ?>
        <table class="table table-dark table-striped table-hover">
            <tr>
                <th>S.N</th>
                <th>Student Name</th>
                <th>Phone Number</th>
                <th>Gender</th>
                <th>City</th>
                <th>Registration Date</th>
                <th>Action</th>
            </tr>
            <?php  $x = 1;
            while ($datas = $select_ayon->fetch_object()) {     
            ?>
            <tr>
                    <td><?= $x?></td>
                    <td><?= $datas->student_name ?></td>
                    <td><?= $datas->gender?></td>
                    <td><?= $datas->phone?></td>
                    <td><?= $datas->city?></td>
                    <td><?= date('d-M-y', strtotime($datas->reg_time)) ?></td>
                    <td><button class="btn btn-light"><i class="fas fa-edit"></i></button> <button class="btn btn-light"><i class="fas fa-trash"></i></button> </td>
            </tr>

                
            <?php $x++;} ?>
        </table>
        <?php } ?>
    </div>
</div>
</div>
<?php 
include_once('./footer.php');
?>
    