<?php 
    include_once('./header.php');

    $select_query = "SELECT * FROM `students`";
    $select = $conn->query($select_query);

    if (!isset($_GET['page'])) {
        header('location: stdinfo.php?page=1');
    }else{
        $page_no = $_GET['page'];
    }

    if(isset($_POST['per_page_btn'])){
        $my_input = $_POST['per_page_search'];
    }else{
        $my_input = 5;
    }

    $student_per_page = $my_input;
    $total_student = $select->num_rows;
    $total_page = ceil($total_student/$student_per_page);
    $start_point = ($page_no-1) * $student_per_page;

    $select_my_query = "SELECT * FROM `students` LIMIT $start_point ,$student_per_page";
    $select_my = $conn->query($select_my_query);

    
?>

<div class="container">
<div class="row py-5 my-5">
    <div class="col-md-10 m-auto p-5 border shadow rounded">
        <h2 class="text-center">Student Informations</h2>
        <table class= "table table-striped ">
            <tr>
                <th>S. No</th>
                <th>Student's Name</th>
                <th>Phone Number</th>
                <th>Gender</th>
                <th>City</th>
                <th>Reg Time</th>
                <th>Actions</th>
            </tr>
            <?php $x= $start_point+1; while ($data = $select_my->fetch_object()) {    
            ?>
            <tr>
                <td><?= $x; ?></td>
                <td><?= $data->student_name?></td>
                <td><?= $data->phone?></td>
                <td><?= $data->gender?></td>
                <td><?= $data->city?></td>
                <td><?= date('d-M-Y' , strtotime($data->reg_time))?></td>
                <td><button class="btn btn-success btn-small mx-1 btn-hover"><i class="fas fa-edit"></i></button><button class="btn btn-danger btn-small"><i class="fas fa-trash"></i></button></td>
            </tr>
            <?php $x++; } ?>
        </table>
        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item <?= $page_no == 1 ? 'd-none' : null;?>"><a class="page-link" href="./stdinfo.php?page=<?= ($page_no != 1)? ($page_no -1):1; ?>">Previous</a></li>

                <?php for ($i=1; $i <= $total_page; $i++) { ?>
                <li class="page-item <?= $page_no == $i ? 'active' : null;?> "><a class="page-link" href="http://localhost/PhpWork/crud3/stdinfo.php?page=<?= $i;?>"><?= $i;?></a></li>
                <?php } ?>

                <li class="page-item <?= $page_no == $total_page ? 'd-none' : null;?>"><a class="page-link" href="./stdinfo.php?page=<?= ($page_no != $total_page)? ($page_no +1):$total_page; ?>">Next</a></li>
            </ul>
            <form action="" method="post">
                <input type="text" class="form-control" placeholder="Enter Your Per Page Number" name="per_page_search">
                <input type="submit" name="per_page_btn" class="btn btn-success btn-small mt-2">
            </form>
        </nav>
    </div>
</div>
</div>
<?php 
include_once('./footer.php');
?>