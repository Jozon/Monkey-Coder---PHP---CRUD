<?php 
$conn = mysqli_connect('localhost' , 'root' ,'', 'crud3');

if(!isset($_GET['id'])){
       header('location: stdinfo.php');
    }else{
        $sid = $_GET['id'];    
    }
    $delete_query= "DELETE FROM `students` WHERE `id` = $sid";
    $delete = $conn->query($delete_query);

    if (!$delete) {
        echo "<script>alert('Something went wrong')</script>";
        echo "<meta http-equiv='refresh' content='0; url=stdinfo.php' />";

        }else{
        echo "<script>alert('Successfull')</script>";
        echo "<meta http-equiv='refresh' content='0; url=stdinfo.php' />";
       
        }

     
?>