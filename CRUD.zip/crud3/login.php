<?php 
include_once('./header.php');


if (isset($_SESSION['uname'])) {
    header("location: index.php");
}

if (isset($_POST['submit'])) {

    $user = safe($_POST['user']);
    $pass = safe($_POST['pass']);
    if (empty($user)) {
        $erruser = "<span style='color:red;'>Please input Your Username</span>";
    }else{
        $crruser = $conn->real_escape_string($user);
    }
    if (empty($pass)) {
        $errpass = "<span style='color:red;'>Please input Your Password</span>";
    }else{
        $crrpass = $conn->real_escape_string(md5($pass));
    }

    if (isset($crruser) && isset($crrpass)) {
        $mysqlquery = "SELECT * FROM `users` WHERE `username` = '$crruser' AND `password` = '$crrpass'";
        $arup = $conn->query($mysqlquery);

        if ($arup->num_rows == 0) {
            $err = "<script>alert('OOPS !! You are Wrong')</script>";
        }else{
            $success = "<script>alert('Hi !! You are successfully logged in')</script>";
            $_SESSION['uname'] = $crruser;
            echo '<meta http-equiv="refresh" content="1;URL=index.php" />'; 
        }
    }
}
?>

<div class="container">
<div class="row py-5 my-5">
    <div class="col-md-6 m-auto p-5 border shadow rounded">
        <h2 class="text-center">Login To Admin Panel</h2>
        <?= $err ?? $success ?? null?>
        
        <form action="" method="post">
        <input type="text" placeholder="Your Username" class="form-control mt-4" name="user">
        <?= $erruser ?? null;?>
        <input type="password" placeholder="Your Password" class="form-control mt-4" name="pass">
        <?= $errpass ?? null;?><br>
        <input type="submit" value="Login" class="btn btn-success btn-small mt-4" name="submit"> 
        </form>
    </div>
</div>
</div>
<?php 
include_once('./footer.php');
?>